/* Created by config.links - do not edit */
/* Host: arm-poky-linux-gnueabi */
static char mod_source_info[] =
  ":generic/mpih-add1.c"
  ":generic/mpih-sub1.c"
  ":generic/mpih-mul1.c"
  ":generic/mpih-mul2.c"
  ":generic/mpih-mul3.c"
  ":generic/mpih-lshift.c"
  ":generic/mpih-rshift.c"
  ;
