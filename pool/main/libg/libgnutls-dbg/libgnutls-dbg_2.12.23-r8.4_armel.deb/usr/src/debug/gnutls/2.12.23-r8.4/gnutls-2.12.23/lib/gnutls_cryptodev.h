void _gnutls_cryptodev_deinit (void);
int _gnutls_cryptodev_init (void);
