#ifndef _GETFD_H
#define _GETFD_H

extern int getfd(const char *fnam);

#endif /* _GETFD_H */
