#ifndef _LTC_PRNG_H_DROPBEAR
#define _LTC_PRNG_H_DROPBEAR

#include "options.h"
#include "includes.h"

#ifdef DROPBEAR_LTC_PRNG

extern const struct ltc_prng_descriptor dropbear_prng_desc;

#endif /* DROPBEAR_LTC_PRNG */

#endif /* _LTC_PRNG_H_DROPBEAR */
