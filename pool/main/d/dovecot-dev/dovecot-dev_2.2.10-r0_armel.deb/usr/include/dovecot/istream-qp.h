#ifndef ISTREAM_QP_H
#define ISTREAM_QP_H

struct istream *i_stream_create_qp_decoder(struct istream *input);

#endif
