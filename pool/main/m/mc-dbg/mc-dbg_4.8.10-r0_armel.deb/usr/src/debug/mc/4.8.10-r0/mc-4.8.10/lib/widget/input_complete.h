#ifndef MC__WIDGET_INPUT_COMPLETE_H
#define MC__WIDGET_INPUT_COMPLETE_H

/*** typedefs(not structures) and defined constants **********************************************/

/*** enums ***************************************************************************************/

/*** structures declarations (and typedefs of structures)*****************************************/

/*** global variables defined in .c file *********************************************************/

/*** declarations of public functions ************************************************************/

void complete (WInput * in);

/*** inline functions ****************************************************************************/

#endif /* MC__WIDGET_INPUT_COMPLETE_H */
