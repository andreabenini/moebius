/** \file chmod.h
 *  \brief Header: chmod command
 */

#ifndef MC__CHMOD_H
#define MC__CHMOD_H

/*** typedefs(not structures) and defined constants **********************************************/

/*** enums ***************************************************************************************/

/*** structures declarations (and typedefs of structures)*****************************************/

/*** global variables defined in .c file *********************************************************/

/*** declarations of public functions ************************************************************/

void chmod_cmd (void);

/*** inline functions ****************************************************************************/
#endif /* MC__CHMOD_H */
