/** \file chown.h
 *  \brief Header: chown command
 */

#ifndef MC__CHOWN_H
#define MC__CHOWN_H

/*** typedefs(not structures) and defined constants **********************************************/

/*** enums ***************************************************************************************/

/*** structures declarations (and typedefs of structures)*****************************************/

/*** global variables defined in .c file *********************************************************/

/*** declarations of public functions ************************************************************/

void chown_cmd (void);

/*** inline functions ****************************************************************************/
#endif /* MC__CHOWN_H */
