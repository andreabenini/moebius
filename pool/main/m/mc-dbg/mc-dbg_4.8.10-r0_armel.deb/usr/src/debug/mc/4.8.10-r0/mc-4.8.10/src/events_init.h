#ifndef MC__EVENTS_INIT_H
#define MC__EVENTS_INIT_H

/*** typedefs(not structures) and defined constants **********************************************/

/*** enums ***************************************************************************************/

/*** structures declarations (and typedefs of structures)*****************************************/

/*** global variables defined in .c file *********************************************************/


/*** declarations of public functions ************************************************************/

gboolean events_init (GError **);

/*** inline functions ****************************************************************************/

#endif /* MC__EVENTS_INIT_H */
