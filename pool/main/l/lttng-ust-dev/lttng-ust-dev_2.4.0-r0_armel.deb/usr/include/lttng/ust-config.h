/* include/lttng/ust-config.h.  Generated from ust-config.h.in by configure.  */
/* ust/config.h.in. Manually generated for control over the contained defs. */

/* Use efficient unaligned access. */
/* #undef LTTNG_UST_HAVE_EFFICIENT_UNALIGNED_ACCESS */

/* DTrace/GDB/SystemTap integration via sdt.h */
/* #undef LTTNG_UST_HAVE_SDT_INTEGRATION */
