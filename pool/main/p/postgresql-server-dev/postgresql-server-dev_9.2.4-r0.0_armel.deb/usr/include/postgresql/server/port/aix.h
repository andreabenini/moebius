/*
 * src/include/port/aix.h
 */
#define CLASS_CONFLICT
#define DISABLE_XOPEN_NLS
