async def foo():
    [i async for i in els]
