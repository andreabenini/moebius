from test import regrtest

regrtest.main_in_temp_cwd()
