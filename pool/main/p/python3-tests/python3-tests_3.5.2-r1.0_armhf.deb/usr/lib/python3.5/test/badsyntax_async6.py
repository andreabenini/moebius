async def foo():
    yield
