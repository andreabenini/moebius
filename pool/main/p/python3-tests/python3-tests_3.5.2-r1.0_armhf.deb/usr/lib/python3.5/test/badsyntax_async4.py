async def foo():
    await
