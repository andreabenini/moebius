#define PHP_ICONV_H_PATH </home/devel/yocto/moebius/tmp/sysroots/raspberrypi/usr/lib/../include/iconv.h>
