#define PHP_ICONV_H_PATH </home/devel/tmp/sysroots/raspberrypi3/usr/lib/../include/iconv.h>
