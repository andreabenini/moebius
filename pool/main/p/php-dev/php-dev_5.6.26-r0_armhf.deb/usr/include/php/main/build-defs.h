/*                                                                -*- C -*-
   +----------------------------------------------------------------------+
   | PHP Version 5                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2016 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig S�ther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

/* $Id$ */

#define CONFIGURE_COMMAND " '../php-5.6.26/configure'  '--build=i686-linux' '--host=arm-poky-linux-gnueabi' '--target=arm-poky-linux-gnueabi' '--prefix=/usr' '--exec_prefix=/usr' '--bindir=/usr/bin' '--sbindir=/usr/sbin' '--libexecdir=/usr/libexec' '--datadir=/usr/share' '--sysconfdir=/etc' '--sharedstatedir=/com' '--localstatedir=/var' '--libdir=/usr/lib' '--includedir=/usr/include' '--oldincludedir=/usr/include' '--infodir=/usr/share/info' '--mandir=/usr/share/man' '--disable-silent-rules' '--disable-dependency-tracking' '--with-libtool-sysroot=/home/devel/tmp/sysroots/raspberrypi3' '--enable-mbstring' '--enable-wddx' '--enable-fpm' '--enable-zip' '--with-libdir=lib' '--with-gettext=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/..' '--with-zlib=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/..' '--with-iconv=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/..' '--with-mcrypt=/home/devel/tmp/sysroots/raspberrypi3/usr' '--with-bz2=/home/devel/tmp/sysroots/raspberrypi3/usr' '--with-config-file-path=/etc/php/apache2-php5' 'ac_cv_c_bigendian_php=no' 'ac_cv_lib_pam_pam_start=no' '--enable-sockets' '--enable-pcntl' '--enable-shared' '--disable-opcache' '--disable-rpath' '--with-pic' '--libdir=/usr/lib/php5' '--disable-static' '--with-imap=/home/devel/tmp/sysroots/raspberrypi3' '--with-imap-ssl=/home/devel/tmp/sysroots/raspberrypi3' '--enable-ipv6' '--with-mysql=/home/devel/tmp/sysroots/raspberrypi3/usr' '--with-mysqli=/home/devel/tmp/sysroots/raspberrypi3/usr/bin/crossscripts/mysql_config' '--with-pdo-mysql=/home/devel/tmp/sysroots/raspberrypi3/usr/bin/crossscripts/mysql_config' '--without-pgsql' '--disable-soap' '--with-sqlite3=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/..' '--with-pdo-sqlite=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/..' '--enable-nls' 'build_alias=i686-linux' 'host_alias=arm-poky-linux-gnueabi' 'target_alias=arm-poky-linux-gnueabi' 'CC=arm-poky-linux-gnueabi-gcc '-march=armv7ve' '-marm' '-mfpu=neon-vfpv4' '-mfloat-abi=hard' '-mcpu=cortex-a7' '--sysroot=/home/devel/tmp/sysroots/raspberrypi3'' 'CFLAGS=-O2 '-pipe' '-g' '-feliminate-unused-debug-types' '-fdebug-prefix-map=/home/devel/tmp/work/cortexa7hf-neon-vfpv4-poky-linux-gnueabi/php/5.6.26-r0=/usr/src/debug/php/5.6.26-r0' '-fdebug-prefix-map=/home/devel/tmp/sysroots/i686-linux=' '-fdebug-prefix-map=/home/devel/tmp/sysroots/raspberrypi3=' '-D_GNU_SOURCE' '-g' '-DPTYS_ARE_GETPT' '-DPTYS_ARE_SEARCHED' '-I/home/devel/tmp/sysroots/raspberrypi3/usr/include/apache2'' 'LDFLAGS=-Wl,-O1 '-Wl,--hash-style=gnu' '-Wl,--as-needed'' 'CPPFLAGS=' 'CPP=arm-poky-linux-gnueabi-gcc '-E' '--sysroot=/home/devel/tmp/sysroots/raspberrypi3' '-march=armv7ve' '-marm' '-mfpu=neon-vfpv4' '-mfloat-abi=hard' '-mcpu=cortex-a7'' 'PKG_CONFIG_PATH=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/pkgconfig:/home/devel/tmp/sysroots/raspberrypi3/usr/share/pkgconfig' 'PKG_CONFIG_LIBDIR=/home/devel/tmp/sysroots/raspberrypi3/usr/lib/pkgconfig' 'CXX=arm-poky-linux-gnueabi-g++ '-march=armv7ve' '-marm' '-mfpu=neon-vfpv4' '-mfloat-abi=hard' '-mcpu=cortex-a7' '--sysroot=/home/devel/tmp/sysroots/raspberrypi3'' 'CXXFLAGS=-O2 '-pipe' '-g' '-feliminate-unused-debug-types' '-fdebug-prefix-map=/home/devel/tmp/work/cortexa7hf-neon-vfpv4-poky-linux-gnueabi/php/5.6.26-r0=/usr/src/debug/php/5.6.26-r0' '-fdebug-prefix-map=/home/devel/tmp/sysroots/i686-linux=' '-fdebug-prefix-map=/home/devel/tmp/sysroots/raspberrypi3=' '-fvisibility-inlines-hidden''"
#define PHP_ADA_INCLUDE		""
#define PHP_ADA_LFLAGS		""
#define PHP_ADA_LIBS		""
#define PHP_APACHE_INCLUDE	""
#define PHP_APACHE_TARGET	""
#define PHP_FHTTPD_INCLUDE      ""
#define PHP_FHTTPD_LIB          ""
#define PHP_FHTTPD_TARGET       ""
#define PHP_CFLAGS		"$(CFLAGS_CLEAN) -prefer-non-pic -static"
#define PHP_DBASE_LIB		""
#define PHP_BUILD_DEBUG		""
#define PHP_GDBM_INCLUDE	""
#define PHP_IBASE_INCLUDE	""
#define PHP_IBASE_LFLAGS	""
#define PHP_IBASE_LIBS		""
#define PHP_IFX_INCLUDE		""
#define PHP_IFX_LFLAGS		""
#define PHP_IFX_LIBS		""
#define PHP_INSTALL_IT		""
#define PHP_IODBC_INCLUDE	""
#define PHP_IODBC_LFLAGS	""
#define PHP_IODBC_LIBS		""
#define PHP_MSQL_INCLUDE	""
#define PHP_MSQL_LFLAGS		""
#define PHP_MSQL_LIBS		""
#define PHP_MYSQL_INCLUDE	"-I/home/devel/tmp/sysroots/raspberrypi3/usr/include/mysql"
#define PHP_MYSQL_LIBS		"-L/home/devel/tmp/sysroots/raspberrypi3/usr/lib -lmysqlclient "
#define PHP_MYSQL_TYPE		"external"
#define PHP_ODBC_INCLUDE	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_SHARED_LIBADD 	""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_ORACLE_SHARED_LIBADD 	"@ORACLE_SHARED_LIBADD@"
#define PHP_ORACLE_DIR				"@ORACLE_DIR@"
#define PHP_ORACLE_VERSION			"@ORACLE_VERSION@"
#define PHP_PGSQL_INCLUDE	""
#define PHP_PGSQL_LFLAGS	""
#define PHP_PGSQL_LIBS		""
#define PHP_PROG_SENDMAIL	""
#define PHP_SOLID_INCLUDE	""
#define PHP_SOLID_LIBS		""
#define PHP_EMPRESS_INCLUDE	""
#define PHP_EMPRESS_LIBS	""
#define PHP_SYBASE_INCLUDE	""
#define PHP_SYBASE_LFLAGS	""
#define PHP_SYBASE_LIBS		""
#define PHP_DBM_TYPE		""
#define PHP_DBM_LIB		""
#define PHP_LDAP_LFLAGS		""
#define PHP_LDAP_INCLUDE	""
#define PHP_LDAP_LIBS		""
#define PHP_BIRDSTEP_INCLUDE     ""
#define PHP_BIRDSTEP_LIBS        ""
#define PEAR_INSTALLDIR         "/usr/lib/php5/php"
#define PHP_INCLUDE_PATH	".:/usr/lib/php5/php"
#define PHP_EXTENSION_DIR       "/usr/lib/php5/extensions/no-debug-non-zts-20131226"
#define PHP_PREFIX              "/usr"
#define PHP_BINDIR              "/usr/bin"
#define PHP_SBINDIR             "/usr/sbin"
#define PHP_MANDIR              "/usr/share/man"
#define PHP_LIBDIR              "/usr/lib/php5"
#define PHP_DATADIR             "/usr/share"
#define PHP_SYSCONFDIR          "/etc"
#define PHP_LOCALSTATEDIR       "/var"
#define PHP_CONFIG_FILE_PATH    "/etc/php/apache2-php5"
#define PHP_CONFIG_FILE_SCAN_DIR    ""
#define PHP_SHLIB_SUFFIX        "so"
