use strict;
use warnings;
package perlfaq;
$perlfaq::VERSION = '5.021009';
1;
