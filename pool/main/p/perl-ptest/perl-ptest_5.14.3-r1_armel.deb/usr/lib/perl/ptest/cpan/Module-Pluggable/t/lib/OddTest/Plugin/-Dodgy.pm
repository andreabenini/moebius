package OddTest::Plugin::-Dodgy;
sub new {}
1;