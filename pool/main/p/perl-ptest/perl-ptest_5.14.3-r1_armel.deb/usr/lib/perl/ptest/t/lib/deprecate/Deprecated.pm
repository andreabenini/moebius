package Deprecated;
use strict;

use deprecate;

q(Harmless);

