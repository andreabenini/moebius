package EditorJunk::Bar;
sub new {}
1;