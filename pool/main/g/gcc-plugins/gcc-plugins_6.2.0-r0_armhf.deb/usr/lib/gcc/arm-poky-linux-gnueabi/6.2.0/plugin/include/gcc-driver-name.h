#define GCC_DRIVER_NAME "arm-poky-linux-gnueabi-gcc-6.2.0"
