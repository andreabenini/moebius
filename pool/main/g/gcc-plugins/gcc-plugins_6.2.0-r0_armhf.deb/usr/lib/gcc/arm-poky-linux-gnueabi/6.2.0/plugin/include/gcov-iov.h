/* Generated automatically by the program `build/gcov-iov'
   from `6.2.0 (6 2) and  (*)'.  */

#define GCOV_VERSION ((gcov_unsigned_t)0x3630322a)  /* 602* */
