#include "cp/lang-specs.h"
#include "lto/lang-specs.h"
