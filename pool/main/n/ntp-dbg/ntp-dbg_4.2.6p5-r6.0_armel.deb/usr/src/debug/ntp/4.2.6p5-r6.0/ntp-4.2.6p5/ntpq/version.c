/*
 * version file for ntpq
 */
#include <config.h>
const char * Version = "ntpq 4.2.6p5@1.2349 Tue Nov 11 22:11:20 UTC 2014 (2)";
