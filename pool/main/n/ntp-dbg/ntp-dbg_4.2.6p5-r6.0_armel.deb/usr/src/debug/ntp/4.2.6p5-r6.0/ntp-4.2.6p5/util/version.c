/*
 * version file for ntp-keygen
 */
#include <config.h>
const char * Version = "ntp-keygen 4.2.6p5@1.2349 Mon Jan 26 09:34:49 UTC 2015 (2)";
