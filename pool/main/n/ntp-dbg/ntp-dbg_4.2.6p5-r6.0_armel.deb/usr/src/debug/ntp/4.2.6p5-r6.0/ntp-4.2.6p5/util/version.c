/*
 * version file for ntp-keygen
 */
#include <config.h>
const char * Version = "ntp-keygen 4.2.6p5@1.2349 Tue Nov 11 22:11:21 UTC 2014 (2)";
