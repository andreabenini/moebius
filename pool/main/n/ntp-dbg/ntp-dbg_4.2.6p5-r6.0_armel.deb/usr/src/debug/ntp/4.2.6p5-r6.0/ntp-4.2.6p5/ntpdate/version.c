/*
 * version file for ntpdate
 */
#include <config.h>
const char * Version = "ntpdate 4.2.6p5@1.2349 Mon Jan 26 09:34:44 UTC 2015 (2)";
