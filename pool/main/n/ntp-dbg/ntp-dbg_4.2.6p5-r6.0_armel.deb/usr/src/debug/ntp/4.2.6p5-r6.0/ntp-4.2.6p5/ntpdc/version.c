/*
 * version file for ntpdc
 */
#include <config.h>
const char * Version = "ntpdc 4.2.6p5@1.2349 Mon Jan 26 09:34:45 UTC 2015 (2)";
