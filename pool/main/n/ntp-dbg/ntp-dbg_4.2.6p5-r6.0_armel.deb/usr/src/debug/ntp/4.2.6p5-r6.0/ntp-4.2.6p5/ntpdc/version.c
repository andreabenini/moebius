/*
 * version file for ntpdc
 */
#include <config.h>
const char * Version = "ntpdc 4.2.6p5@1.2349 Tue Nov 11 22:11:19 UTC 2014 (2)";
