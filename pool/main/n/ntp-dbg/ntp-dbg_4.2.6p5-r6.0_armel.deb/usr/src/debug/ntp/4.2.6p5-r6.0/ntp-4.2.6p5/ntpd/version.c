/*
 * version file for ntpd
 */
#include <config.h>
const char * Version = "ntpd 4.2.6p5@1.2349 Tue Nov 11 22:11:17 UTC 2014 (2)";
