/*
 * version file for ntpd
 */
#include <config.h>
const char * Version = "ntpd 4.2.6p5@1.2349 Mon Jan 26 09:34:43 UTC 2015 (2)";
