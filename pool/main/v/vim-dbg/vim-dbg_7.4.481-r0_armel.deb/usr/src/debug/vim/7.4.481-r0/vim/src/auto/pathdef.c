/* pathdef.c */
/* This file is automatically created by Makefile
 * DO NOT EDIT!  Change Makefile only. */
#include "vim.h"
char_u *default_vim_dir = (char_u *)"/usr/share/vim";
char_u *default_vimruntime_dir = (char_u *)"";
char_u *all_cflags = (char_u *)"arm-poky-linux-gnueabi-gcc  -march=armv6 -mthumb-interwork -mfloat-abi=hard -mtune=arm1176jzf-s -mfpu=vfp --sysroot=/home/devel/yocto/moebius/tmp/sysroots/raspberrypi -c -I. -Iproto -DHAVE_CONFIG_H     -O2 -pipe -g -feliminate-unused-debug-types -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=1      ";
char_u *all_lflags = (char_u *)"arm-poky-linux-gnueabi-gcc  -march=armv6 -mthumb-interwork -mfloat-abi=hard -mtune=arm1176jzf-s -mfpu=vfp --sysroot=/home/devel/yocto/moebius/tmp/sysroots/raspberrypi   -Wl,-O1 -Wl,--hash-style=gnu -Wl,--as-needed -o vim        -lm  -lncurses -ldl          ";
char_u *compiled_user = (char_u *)"devel";
char_u *compiled_sys = (char_u *)"yocto";
