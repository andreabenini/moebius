/* This is a generated file, don't edit */

#define NUM_APPLETS 155

const char applet_names[] ALIGN1 = ""
"addgroup" "\0"
"adduser" "\0"
"ash" "\0"
"awk" "\0"
"basename" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"cat" "\0"
"chattr" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chpasswd" "\0"
"chroot" "\0"
"chvt" "\0"
"clear" "\0"
"cp" "\0"
"cpio" "\0"
"cut" "\0"
"date" "\0"
"dd" "\0"
"deallocvt" "\0"
"delgroup" "\0"
"deluser" "\0"
"depmod" "\0"
"df" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsdomainname" "\0"
"du" "\0"
"dumpkmap" "\0"
"echo" "\0"
"egrep" "\0"
"env" "\0"
"ether-wake" "\0"
"expr" "\0"
"false" "\0"
"fbset" "\0"
"fdisk" "\0"
"fgrep" "\0"
"find" "\0"
"flock" "\0"
"free" "\0"
"fsck" "\0"
"fstrim" "\0"
"ftpput" "\0"
"fuser" "\0"
"getty" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"head" "\0"
"hexdump" "\0"
"hostname" "\0"
"hwclock" "\0"
"id" "\0"
"ifconfig" "\0"
"ifdown" "\0"
"ifup" "\0"
"insmod" "\0"
"ip" "\0"
"kill" "\0"
"killall" "\0"
"klogd" "\0"
"less" "\0"
"ln" "\0"
"loadkmap" "\0"
"logger" "\0"
"losetup" "\0"
"ls" "\0"
"lsmod" "\0"
"lsof" "\0"
"md5sum" "\0"
"microcom" "\0"
"mkdir" "\0"
"mkfifo" "\0"
"mknod" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mv" "\0"
"nc" "\0"
"netstat" "\0"
"nohup" "\0"
"nslookup" "\0"
"openvt" "\0"
"patch" "\0"
"pidof" "\0"
"pivot_root" "\0"
"poweroff" "\0"
"printf" "\0"
"ps" "\0"
"pwd" "\0"
"rdate" "\0"
"readlink" "\0"
"realpath" "\0"
"reboot" "\0"
"renice" "\0"
"reset" "\0"
"rfkill" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"run-parts" "\0"
"sed" "\0"
"setconsole" "\0"
"sh" "\0"
"sha3sum" "\0"
"sleep" "\0"
"sort" "\0"
"start-stop-daemon" "\0"
"stat" "\0"
"strings" "\0"
"stty" "\0"
"sulogin" "\0"
"swapoff" "\0"
"swapon" "\0"
"switch_root" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tail" "\0"
"tar" "\0"
"tee" "\0"
"telnet" "\0"
"tftp" "\0"
"time" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"true" "\0"
"tty" "\0"
"udhcpc" "\0"
"umount" "\0"
"uname" "\0"
"uniq" "\0"
"unzip" "\0"
"uptime" "\0"
"usleep" "\0"
"vi" "\0"
"watch" "\0"
"wc" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"whois" "\0"
"xargs" "\0"
"yes" "\0"
"zcat" "\0"
;

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
addgroup_main,
adduser_main,
ash_main,
awk_main,
basename_main,
bunzip2_main,
bunzip2_main,
cat_main,
chattr_main,
chgrp_main,
chmod_main,
chown_main,
chpasswd_main,
chroot_main,
chvt_main,
clear_main,
cp_main,
cpio_main,
cut_main,
date_main,
dd_main,
deallocvt_main,
deluser_main,
deluser_main,
depmod_main,
df_main,
diff_main,
dirname_main,
dmesg_main,
hostname_main,
du_main,
dumpkmap_main,
echo_main,
grep_main,
env_main,
ether_wake_main,
expr_main,
false_main,
fbset_main,
fdisk_main,
grep_main,
find_main,
flock_main,
free_main,
fsck_main,
fstrim_main,
ftpgetput_main,
fuser_main,
getty_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
halt_main,
head_main,
hexdump_main,
hostname_main,
hwclock_main,
id_main,
ifconfig_main,
ifupdown_main,
ifupdown_main,
insmod_main,
ip_main,
kill_main,
kill_main,
klogd_main,
less_main,
ln_main,
loadkmap_main,
logger_main,
losetup_main,
ls_main,
lsmod_main,
lsof_main,
md5_sha1_sum_main,
microcom_main,
mkdir_main,
mkfifo_main,
mknod_main,
mkswap_main,
mktemp_main,
modprobe_main,
more_main,
mount_main,
mv_main,
nc_main,
netstat_main,
nohup_main,
nslookup_main,
openvt_main,
patch_main,
pidof_main,
pivot_root_main,
halt_main,
printf_main,
ps_main,
pwd_main,
rdate_main,
readlink_main,
realpath_main,
halt_main,
renice_main,
reset_main,
rfkill_main,
rm_main,
rmdir_main,
rmmod_main,
route_main,
run_parts_main,
sed_main,
setconsole_main,
ash_main,
md5_sha1_sum_main,
sleep_main,
sort_main,
start_stop_daemon_main,
stat_main,
strings_main,
stty_main,
sulogin_main,
swap_on_off_main,
swap_on_off_main,
switch_root_main,
sync_main,
sysctl_main,
syslogd_main,
tail_main,
tar_main,
tee_main,
telnet_main,
tftp_main,
time_main,
top_main,
touch_main,
tr_main,
true_main,
tty_main,
udhcpc_main,
umount_main,
uname_main,
uniq_main,
unzip_main,
uptime_main,
usleep_main,
vi_main,
watch_main,
wc_main,
which_main,
who_main,
whoami_main,
whois_main,
xargs_main,
yes_main,
gunzip_main,
};
#endif

const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0009,
0x0011,
0x0015,
0x0019,
0x0022,
0x002a,
0x0030,
0x0034,
0x003b,
0x0041,
0x0047,
0x004d,
0x0056,
0x005d,
0x0062,
0x0068,
0x006b,
0x0070,
0x0074,
0x0079,
0x007c,
0x0086,
0x008f,
0x0097,
0x009e,
0x00a1,
0x00a6,
0x00ae,
0x00b4,
0x00c2,
0x00c5,
0x00ce,
0x00d3,
0x00d9,
0x00dd,
0x00e8,
0x00ed,
0x00f3,
0x00f9,
0x00ff,
0x0105,
0x010a,
0x0110,
0x0115,
0x011a,
0x0121,
0x0128,
0x012e,
0x0134,
0x0139,
0x0140,
0x0147,
0x014c,
0x0151,
0x0156,
0x015e,
0x0167,
0x016f,
0x0172,
0x017b,
0x0182,
0x0187,
0x018e,
0x0191,
0x0196,
0x019e,
0x01a4,
0x01a9,
0x01ac,
0x01b5,
0x01bc,
0x01c4,
0x01c7,
0x01cd,
0x01d2,
0x01d9,
0x01e2,
0x01e8,
0x01ef,
0x01f5,
0x01fc,
0x0203,
0x020c,
0x0211,
0x0217,
0x021a,
0x021d,
0x0225,
0x022b,
0x0234,
0x023b,
0x0241,
0x0247,
0x0252,
0x025b,
0x0262,
0x0265,
0x0269,
0x026f,
0x0278,
0x0281,
0x0288,
0x028f,
0x0295,
0x029c,
0x029f,
0x02a5,
0x02ab,
0x02b1,
0x02bb,
0x02bf,
0x02ca,
0x02cd,
0x02d5,
0x02db,
0x02e0,
0x02f2,
0x02f7,
0x02ff,
0x0304,
0x030c,
0x0314,
0x031b,
0x0327,
0x032c,
0x0333,
0x033b,
0x0340,
0x0344,
0x0348,
0x034f,
0x0354,
0x0359,
0x035d,
0x0363,
0x0366,
0x036b,
0x036f,
0x0376,
0x037d,
0x0383,
0x0388,
0x038e,
0x0395,
0x039c,
0x039f,
0x03a5,
0x03a8,
0x03ae,
0x03b2,
0x03b9,
0x03bf,
0x03c5,
0x03c9,
};

