/* This is a generated file, don't edit */

#define NUM_APPLETS 156

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"ash" "\0"
"awk" "\0"
"basename" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"cat" "\0"
"chattr" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chroot" "\0"
"chvt" "\0"
"clear" "\0"
"cmp" "\0"
"cp" "\0"
"cpio" "\0"
"cut" "\0"
"date" "\0"
"dd" "\0"
"deallocvt" "\0"
"depmod" "\0"
"df" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsdomainname" "\0"
"dos2unix" "\0"
"du" "\0"
"dumpkmap" "\0"
"echo" "\0"
"egrep" "\0"
"env" "\0"
"expr" "\0"
"false" "\0"
"fdisk" "\0"
"fgrep" "\0"
"find" "\0"
"flock" "\0"
"free" "\0"
"fsck" "\0"
"fstrim" "\0"
"fuser" "\0"
"getty" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"head" "\0"
"hexdump" "\0"
"hostname" "\0"
"hwclock" "\0"
"id" "\0"
"ifconfig" "\0"
"ifdown" "\0"
"ifup" "\0"
"insmod" "\0"
"ip" "\0"
"kill" "\0"
"killall" "\0"
"klogd" "\0"
"less" "\0"
"ln" "\0"
"loadkmap" "\0"
"logger" "\0"
"logname" "\0"
"logread" "\0"
"losetup" "\0"
"ls" "\0"
"lsmod" "\0"
"lsusb" "\0"
"md5sum" "\0"
"microcom" "\0"
"mkdir" "\0"
"mkfifo" "\0"
"mknod" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modinfo" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mv" "\0"
"nc" "\0"
"netstat" "\0"
"nohup" "\0"
"nslookup" "\0"
"od" "\0"
"patch" "\0"
"pidof" "\0"
"pivot_root" "\0"
"poweroff" "\0"
"printf" "\0"
"ps" "\0"
"pwd" "\0"
"readlink" "\0"
"realpath" "\0"
"reboot" "\0"
"renice" "\0"
"reset" "\0"
"rfkill" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"run-parts" "\0"
"sed" "\0"
"seq" "\0"
"sh" "\0"
"sha1sum" "\0"
"sha256sum" "\0"
"sha3sum" "\0"
"sha512sum" "\0"
"sleep" "\0"
"sort" "\0"
"start-stop-daemon" "\0"
"stat" "\0"
"strings" "\0"
"stty" "\0"
"sulogin" "\0"
"swapoff" "\0"
"swapon" "\0"
"switch_root" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tail" "\0"
"tar" "\0"
"tee" "\0"
"test" "\0"
"time" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"true" "\0"
"tty" "\0"
"tune2fs" "\0"
"udhcpc" "\0"
"umount" "\0"
"uname" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unzip" "\0"
"uptime" "\0"
"usleep" "\0"
"vi" "\0"
"watch" "\0"
"wc" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"xargs" "\0"
"yes" "\0"
"zcat" "\0"
;

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
ash_main,
awk_main,
basename_main,
bunzip2_main,
bunzip2_main,
cat_main,
chattr_main,
chgrp_main,
chmod_main,
chown_main,
chroot_main,
chvt_main,
clear_main,
cmp_main,
cp_main,
cpio_main,
cut_main,
date_main,
dd_main,
deallocvt_main,
depmod_main,
df_main,
diff_main,
dirname_main,
dmesg_main,
hostname_main,
dos2unix_main,
du_main,
dumpkmap_main,
echo_main,
grep_main,
env_main,
expr_main,
false_main,
fdisk_main,
grep_main,
find_main,
flock_main,
free_main,
fsck_main,
fstrim_main,
fuser_main,
getty_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
halt_main,
head_main,
hexdump_main,
hostname_main,
hwclock_main,
id_main,
ifconfig_main,
ifupdown_main,
ifupdown_main,
insmod_main,
ip_main,
kill_main,
kill_main,
klogd_main,
less_main,
ln_main,
loadkmap_main,
logger_main,
logname_main,
logread_main,
losetup_main,
ls_main,
lsmod_main,
lsusb_main,
md5_sha1_sum_main,
microcom_main,
mkdir_main,
mkfifo_main,
mknod_main,
mkswap_main,
mktemp_main,
modinfo_main,
modprobe_main,
more_main,
mount_main,
mv_main,
nc_main,
netstat_main,
nohup_main,
nslookup_main,
od_main,
patch_main,
pidof_main,
pivot_root_main,
halt_main,
printf_main,
ps_main,
pwd_main,
readlink_main,
realpath_main,
halt_main,
renice_main,
reset_main,
rfkill_main,
rm_main,
rmdir_main,
rmmod_main,
route_main,
run_parts_main,
sed_main,
seq_main,
ash_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
sleep_main,
sort_main,
start_stop_daemon_main,
stat_main,
strings_main,
stty_main,
sulogin_main,
swap_on_off_main,
swap_on_off_main,
switch_root_main,
sync_main,
sysctl_main,
syslogd_main,
tail_main,
tar_main,
tee_main,
test_main,
time_main,
top_main,
touch_main,
tr_main,
true_main,
tty_main,
tune2fs_main,
udhcpc_main,
umount_main,
uname_main,
uniq_main,
dos2unix_main,
unzip_main,
uptime_main,
usleep_main,
vi_main,
watch_main,
wc_main,
which_main,
who_main,
whoami_main,
xargs_main,
yes_main,
gunzip_main,
};
#endif

const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0002,
0x0005,
0x0009,
0x000d,
0x0016,
0x001e,
0x0024,
0x0028,
0x002f,
0x0035,
0x003b,
0x0041,
0x0048,
0x004d,
0x0053,
0x0057,
0x005a,
0x005f,
0x0063,
0x0068,
0x006b,
0x0075,
0x007c,
0x007f,
0x0084,
0x008c,
0x0092,
0x00a0,
0x00a9,
0x00ac,
0x00b5,
0x00ba,
0x00c0,
0x00c4,
0x00c9,
0x00cf,
0x00d5,
0x00db,
0x00e0,
0x00e6,
0x00eb,
0x00f0,
0x00f7,
0x00fd,
0x0103,
0x0108,
0x010f,
0x0116,
0x011b,
0x0120,
0x0125,
0x012d,
0x0136,
0x013e,
0x0141,
0x014a,
0x0151,
0x0156,
0x015d,
0x0160,
0x0165,
0x016d,
0x0173,
0x0178,
0x017b,
0x0184,
0x018b,
0x0193,
0x019b,
0x01a3,
0x01a6,
0x01ac,
0x01b2,
0x01b9,
0x01c2,
0x01c8,
0x01cf,
0x01d5,
0x01dc,
0x01e3,
0x01eb,
0x01f4,
0x01f9,
0x01ff,
0x0202,
0x0205,
0x020d,
0x0213,
0x021c,
0x021f,
0x0225,
0x022b,
0x0236,
0x023f,
0x0246,
0x0249,
0x024d,
0x0256,
0x025f,
0x0266,
0x026d,
0x0273,
0x027a,
0x027d,
0x0283,
0x0289,
0x028f,
0x0299,
0x029d,
0x02a1,
0x02a4,
0x02ac,
0x02b6,
0x02be,
0x02c8,
0x02ce,
0x02d3,
0x02e5,
0x02ea,
0x02f2,
0x02f7,
0x02ff,
0x0307,
0x030e,
0x031a,
0x031f,
0x0326,
0x032e,
0x0333,
0x0337,
0x033b,
0x0340,
0x0345,
0x0349,
0x034f,
0x0352,
0x0357,
0x035b,
0x0363,
0x036a,
0x0371,
0x0377,
0x037c,
0x0385,
0x038b,
0x0392,
0x0399,
0x039c,
0x03a2,
0x03a5,
0x03ab,
0x03af,
0x03b6,
0x03bc,
0x03c0,
};

