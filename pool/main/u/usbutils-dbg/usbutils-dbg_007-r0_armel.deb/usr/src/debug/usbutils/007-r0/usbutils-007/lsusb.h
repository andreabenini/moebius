#ifndef _LSUSB_H
#define _LSUSB_H

extern int lsusb_t(void);

#endif
