#warning This header is deprecated, use <alsa/asoundlib.h> instead.
#include <alsa/asoundlib.h>
