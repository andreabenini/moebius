#!/bin/sh
# This file will be synced with remote repository distribution, do not alter it

# Local variables, they can be used from containers scripts
CONTAINERNAME=$2            # Name of the current container
ACTION=$1                   # Current action (install|remove|configure|...)
PACKAGEPATH=$3              # Current package fullpath
COLS=`tput cols`            # Screen columns

# Internal variables, do not touch these
LINE=''


# PACKAGE INSTALL - Install a package from the system
#       Actually a wrapper of apt-get but please use this function instead of apt-utils
# Example: PackageInstall bash
PackageInstall() {
    apt-get install $1
}

# PACKAGE REMOVE - Remove a package from the system
#       Actually a wrapper of apt-get but please use this function instead of apt-utils
# Example: PackageRemove bash
PackageRemove() {
    apt-get purge -y $1
}

# PAGE BREAK - Print a full line of "-" as separator
#
# Example: PageBreak
PageBreak() {
    I=0
    if [ "$LINE" != "" ]; then
        echo -n $LINE
        return
    fi
    while [[ $I -lt $COLS ]]; do
        LINE="$LINE-"
        I=`expr $I + 1`
    done
    echo -n $LINE
}

# MESSAGE CENTER - Center a message in the middle of the screen
#
# Example: MessageCenter "Hello"
MessageCenter() {
    LEN=${#1}
    SPACES=$((((COLS-LEN))/2))
    printf %${SPACES}s
    echo $1
}

source $PACKAGEPATH/$ACTION
if [ "$ACTION" = "remove" ]; then
    rm -rf "$PACKAGEPATH"
fi
exit 0