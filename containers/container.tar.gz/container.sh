#!/bin/sh
# This file will be synced with remote repository distribution, do not alter it

# Local variables, they can be used from containers scripts
CONTAINERNAME=$2            # Name of the current container
ACTION=$1                   # Current action (install|remove|configure|...)
PACKAGEPATH=$3              # Current package fullpath
if [ "`which tput`" = "" ]; then
    COLS=20                     # tput not found, just set a line of 20 cols
else
    COLS=`tput cols`            # Screen columns
fi

# Internal variables, do not touch these
LINE=''


# PACKAGE INSTALL - Install a package from the system
#       Actually a wrapper of apt-get but please use this function instead of apt-utils
# Example: PackageInstall <packagename>
PackageInstall() {
    apt-get -y install $1
}

# PACKAGE REMOVE - Remove a package from the system
#       Actually a wrapper of apt-get but please use this function instead of apt-utils
# Example: PackageRemove <packagename>
PackageRemove() {
    apt-get purge -y $1
}

# PACKAGE AUTO REMOVE - Remove unused package from system
#       Actually a wrapper of apt-get but please use this function instead of apt-utils
# Example: PackageAutoRemove
PackageAutoRemove() {
    apt-get autoremove -y
}

# CONTAINER INSTALL - Install a container in this system
#
ContainerInstall() {
    moebius container install $1
}

# CONTAINER INSTALL IF NEEDED - Install a container if it's not present in this system
# @param ($1) Container name
# @param ($2) Name of the daemon to search, do not install if it's found running
ContainerInstallIfNeeded() {
    if [ "`moebius container list installed |grep ^$2`" = "" ]; then
        ContainerInstall $1
    fi
}

# CONTAINER CHECK IF INSTALLED - Detect if a container is installed or not
# @param ($1) Container Name
#
# @return 0 if container is not installed, 1 if it's installed
ContainerCheckIfInstalled() {
    if [ "`moebius container list installed | grep ^$1`" = "" ]; then
        return 0
    fi
    return 1
}

# CONTAINER REMOVE - Remove a container from this system
#
ContainerRemove() {
    moebius container remove $1
}

ServiceStart() {
    /etc/init.d/$1 start
}
ServiceRestart() {
    /etc/init.d/$1 restart
}
ServiceStop() {
    /etc/init.d/$1 stop 2>/dev/null
}

# PAGE BREAK - Print a full line of "-" as separator
#
# Example: PageBreak
PageBreak() {
    I=0
    if [ "$LINE" != "" ]; then
        echo -n $LINE
        return
    fi
    while [[ $I -lt $COLS ]]; do
        LINE="$LINE-"
        I=`expr $I + 1`
    done
    echo -n $LINE
}

# MESSAGE CENTER - Center a message in the middle of the screen
#
# Example: MessageCenter "Hello"
MessageCenter() {
    LEN=${#1}
    SPACES=$((((COLS-LEN))/2))
    printf %${SPACES}s
    echo $1
}

source $PACKAGEPATH/$ACTION
if [ "$ACTION" = "remove" ]; then
    rm -rf "$PACKAGEPATH"
fi
exit 0
